// Add JavaScript code to capture the click event on the "Add to Wishlist" button
const addToWishlistButtons = document.querySelectorAll(".add-to-wishlist");
addToWishlistButtons.forEach(button => {
  button.addEventListener("click", () => {
    const item = button.parentNode;
    // Save the item to the user's wishlist (you can use localStorage or a server-side database to do this)
    // Example using localStorage:
    const savedItems = JSON.parse(localStorage.getItem("wishlist")) || [];
    savedItems.push(item);
    localStorage.setItem("wishlist", JSON.stringify(savedItems));
  });
});
